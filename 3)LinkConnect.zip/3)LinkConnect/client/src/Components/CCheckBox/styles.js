import { makeStyles } from "@mui/styles";

const styles = makeStyles({
   checkbox:{
    color:"BCA9C6",
    fontSize:'10px'
   }
});

export default styles;
