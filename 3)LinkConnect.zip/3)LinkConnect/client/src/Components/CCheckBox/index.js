import React from 'react'
import Checkbox from '@mui/material/Checkbox';

const CCheckBox = (props) => {


  return (
    <div>
      <Checkbox {...props}/>
    </div>
  )
}

export default CCheckBox;
